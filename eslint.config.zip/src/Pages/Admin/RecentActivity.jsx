import React from "react";
import Index from "./Layout/Index";

const RecentActivity = () => {
  return (
    <>
      <div>RecentActivity</div>
    </>
  );
};

export default RecentActivity;
